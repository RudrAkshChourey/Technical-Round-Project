<?php
session_start();
include 'config.php';

$id =$_GET['id'];
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$sql1 = "UPDATE registration SET name='$name',email='$email',phone='$phone' WHERE id=$id";
if(mysqli_query($conn, $sql1)){

   $message= "UpDate Successfull ";
   echo "<script> alert('$message'); 
       window.location.href = './dashboard.php';
   </script>";
  
} else{
   echo "<div>ERROR: Could not able to execute <div>$sql. " . mysqli_error($conn);
}
mysqli_close($conn);
