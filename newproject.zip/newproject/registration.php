<?php
include 'config.php';

$name = $_POST["name"];
$username = $_POST["username"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$password = md5($_POST["password"]);
$confpassword = md5($_POST["confpassword"]);

    // Generate a unique verification code
$verificationCode = generateUniqueCode();

$select = mysqli_query($conn, "SELECT * FROM registration WHERE email = '" . $email. "'");
if (mysqli_num_rows($select)) {

    echo '<script>alert("This email address is already used !!");</script>';
    echo '<script>window.location.href = "./";</script>';
    exit();
}

$select = mysqli_query($conn, "SELECT * FROM registration WHERE username = '" . $username. "'");
if (mysqli_num_rows($select)) {

    echo '<script>alert("This Username is Already Taken !!");</script>';
    echo '<script>window.location.href = "./";</script>';
    exit();
}

if ($password === $confpassword) {

$sql = "INSERT INTO registration (name,username,email,phone,password,verification_code)
 VALUES ('$name','$username','$email','$phone','$password','$verificationCode')";

if(mysqli_query($conn, $sql)){

    // Send activation email
    $activationLink = "./verify.php?code=" . urlencode($verificationCode);
    $emailContent = "Please click the following link to activate your account: $activationLink";
    mail($email, "Account Activation", $emailContent);

    // Redirect to a page informing the user to check their email
    header("Location: activation_pending.php");
    exit();


} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}
}

else {
    
    $pssmessage = "Password Not Matched !! ";
    echo "<script> alert('$pssmessage'); 
    window.location.href = './';
    </script>";
}



// Helper function to generate a unique verification code
function generateUniqueCode() {
    $code = uniqid();
    // You can add additional checks here to ensure code uniqueness if required
    return $code;
}


mysqli_close($conn); 

?>