<?php
session_start();
if (session_destroy()){  
  echo '<script>alert("You Are Logged Out !!");</script>';   
  echo '<script>window.location.href = "./";</script>';
  exit();
}


?>