<?php
include 'config.php';
if (isset($_GET['code'])) {
    $verificationCode = $_GET['code'];

    // Find user with matching verification code
    $stmt = "SELECT * FROM registration WHERE verification_code = $verificationCode";
    $result = mysqli_query($conn, $stmt);
    $user = mysqli_fetch_array($result);
   
    if ($user) {
        $usrid= $user['id'];
        // Mark the user as verified
        $stmt = $conn->prepare("UPDATE registration SET is_verified = 1 WHERE id = $usrid");
        $stmt->execute([$user['id']]);

        // Redirect to a success page
        header("Location: verification_success.php");
        exit();
    }
    else {
        // Redirect to an error page
        header("Location: verification_error.php");
        exit();
    }
}


?>