<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "newproject";
$conn = new mysqli($servername, $username, $password, $dbname);

    if (!$conn)
    {
        die("Connection not stablished". mysqli_connect_error());

    }
    else{
        echo" <br>";
    }


?>