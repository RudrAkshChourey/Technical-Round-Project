<?php
session_start();
include 'config.php';

if (!isset($_SESSION)) {

    include './header.php';
  } else {
    include './dashboardheader.php';
  }

$db = $conn;
$tableName = "registration";
$id = $_GET['id'];


    $query = "DELETE FROM $tableName WHERE id = $id";
    if (mysqli_query($conn, $query)) {

         // End the session
        session_unset();
        session_destroy();
        echo '<script>alert("Account Deleted Successfull !!");</script>';
        echo '<script>window.location.href = "./logout.php";</script>';
        exit();
    }
    else {
        echo '<script>alert("Account Not Deleted !!");</script>';
    }

mysqli_close($conn);
include './footer.php';
 ?>
