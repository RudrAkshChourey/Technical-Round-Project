<?php
session_start();

include 'config.php';
$db = $conn;
$tableName = "registration";
$dname = $_SESSION['name'];
$did = $_SESSION['id'];

if (!isset($_SESSION)) {

  include './header.php';
} else {
  include './dashboardheader.php';
}

$query = "SELECT * FROM $tableName WHERE id= '$did'";
$result = mysqli_query($db, $query);
$row = mysqli_fetch_array($result);

  ?>

    <div class="box-wrap">
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo $row['name'] ?? ''; ?></td>
                        <td><?php echo $row['email'] ?? ''; ?></td>
                        <td><?php echo $row['phone'] ?? ''; ?></td>
                    </tr>
                    <tr>
                        <td><a href="./editview.php?id=<?php echo $row['id']; ?>" class="btn btn-warning">Edit</a></td>
                        <td> <a href="./changepassview.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">Change Password</a></td>
                        <td> <a href="./deleteprofile.php?id=<?php echo $row['id']; ?>" class="btn btn-danger">Delete</a> </td>
                    </tr>
                   
                </tbody>
            </table>
        </div>
    </div>

    <?php
    mysqli_close($conn);
    include './footer.php'; 
    ?>


