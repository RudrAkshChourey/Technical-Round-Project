<?php
session_start();

if (!isset($_SESSION)) {

    include './header.php';
  } else {
    include './dashboardheader.php';
  }

include 'config.php';
$db = $conn;
$tableName = "registration";

$id = $_GET['id'];
$query = "SELECT * FROM $tableName WHERE id = $id";
$result = mysqli_query($db, $query);
$row = mysqli_fetch_array($result);
?>
                    <div class="container">
                        <div class="form-wrap">
                            <form class="row g-3 needs-validation" action="./editpost.php?id=<?php echo $id; ?>" enctype="multipart/form-data" method = "POST" novalidate>
                                <div class="col-md-12">
                                    <label for="validationCustom01" class="form-label">Name</label>
                                    <input type="text" class="form-control" id="validationCustom01" value="<?php echo $row['name']; ?>" name="name" required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <label for="validationCustom06" class="form-label">Phone No.</label>
                                    <input type="number" class="form-control" id="validationCustom06" value="<?php echo $row['phone']; ?>" name="phone" maxlength="10" required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <label for="validationCustom03" class="form-label">Email Address</label>
                                    <input type="email" name="email" class="form-control" id="validationCustom03" value="<?php echo $row['email']; ?>"
                                        required>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button class="btn btn-primary" value="update" name="update" type="submit">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>

<?php
mysqli_close($conn);
include './footer.php';
?>