<?php
session_start();
include 'config.php';

$id = $_GET['id'];
$oldpassword = md5($_POST["oldpassword"]);
$newpassword = md5($_POST["newpassword"]);
$confnewpass = md5($_POST["confnewpassword"]);

if ($newpassword === $confnewpass) {

$sql = "SELECT password FROM registration WHERE id = $id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);

if ($row["password"] == $oldpassword) {

   $sql1 = "UPDATE registration SET password='$newpassword' ";
   $result1 = mysqli_query($conn, $sql1);
   if (mysqli_query($conn, $sql1)) {
      echo '<script> alert("Password  Successully Changed !! "); </script>';
      echo '<script>window.location.href = "./dashboard.php";</script>';
        exit();
   }
} else {

   echo '<script>alert("Please Enter Valid Old Password !!");</script>';
   echo '<script>window.location.href = "./changepassview.php?id='.$id.'";</script>';
   exit();
}

}
else {
    echo '<script>alert("Please Confirm New Password!!");</script>';
    echo '<script>window.location.href = "./changepassview.php?id='.$id.'";</script>';
    exit();

}


