<?php
    
     session_start();
     if (!isset($_SESSION["name"])) {
   
       include './header.php';
     } else {
       include './dashboardheader.php';
     }
  ?>
<h5>Account Activation Pending</h5>
    <p>Thank you for registering. An email has been sent to your email address. Please check your inbox and click the activation link to activate your account.</p>

<?php include './footer.php'; ?>