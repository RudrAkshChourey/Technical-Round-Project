<?php

include 'config.php';

$email = $_POST["email1"];
$password = md5($_POST["loginpass"]);

$sql = "SELECT * FROM registration WHERE email = '$email' AND password = '$password'";
$result = mysqli_query($conn, $sql);
$check = mysqli_fetch_array($result);

if (isset($check) && $check['is_verified'] == 1)  {
    session_start();
    $_SESSION = $check;
    if (isset($_SESSION["name"]) && ($_SESSION["id"]) && ($_SESSION["username"])) {

        $message = "Sign-In Success!!  Welcome ";
        echo "<script> alert('$message'); 
         window.location.href = './dashboard.php';
    </script>";
    }
} else {
    echo '<script>alert("Invalid Credentials Or Email Is Not Verified !!");</script>';
    echo '<script>window.location.href = "./";</script>';
    exit();
}
