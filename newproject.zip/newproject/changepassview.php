<?php
session_start();
if (!isset($_SESSION)) {

  include './header.php';
} else {
  include './dashboardheader.php';
}
include 'config.php';
$db = $conn;

$id = $_GET['id'];
?>

<div class="d-flex justify-content-lg-around">
  <form class="row g-3 needs-validation" id="changepass" method="POST" action="./changepasspost.php?id=<?php echo $id; ?>">
    <h3>Change Your Password Here!!</h3><br>
    <div class="col-md-12">
        <label for="validationDefaultpass" class="form-label">Current Password </label>
        <div class="input-group">
            <input type="password" name="oldpassword" class="form-control" id="validationDefaultpass" aria-describedby="inputGroupPrepend2" minlength="5" maxlength="16" required>
        </div>
    </div>
    <div class="col-md-12">
        <label for="validationDefaultpass" class="form-label">New Password</label>
        <div class="input-group">
            <input type="password" class="form-control" name="newpassword" id="validationDefaultpass" aria-describedby="inputGroupPrepend2" minlength="5" maxlength="16" required>
        </div>
    </div>

    <div class="col-md-12">
        <label for="validationDefaultpass" class="form-label">Confirm New Password</label>
        <div class="input-group">
            <input type="password" class="form-control" name="confnewpassword" id="validationDefaultpass" aria-describedby="inputGroupPrepend2" minlength="5" maxlength="16" required>
        </div>
    </div>

    <div class="form-group">
      <button class="btn btn-primary" name="change" id="submit" type="submit">Change</button>
    </div>
  </form>
</div>


<?php

include './footer.php'; ?>